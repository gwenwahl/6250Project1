#include "stdafx.h"
#include "point.h"


point::point()
{
}


point::~point()
{
}
